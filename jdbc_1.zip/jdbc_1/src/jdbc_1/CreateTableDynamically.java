package jdbc_1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateTableDynamically {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		String url = "jdbc:mysql://localhost:3307/custdb?createDatabaseIfNotExist=true";
		String uname = "root";
		String pwd = "root";
		Connection con = DriverManager.getConnection(url, uname, pwd);
		Statement sta = con.createStatement();
		sta.execute("create table cust(id int primary key,name varchar(20),deposit int)");
		con.close();
		sta.close();
		System.out.println("created");

	}

}
