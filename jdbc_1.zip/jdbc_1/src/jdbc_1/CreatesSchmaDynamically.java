package jdbc_1;

import java.sql.DriverManager;
import java.sql.SQLException;

public class CreatesSchmaDynamically {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		String url="jdbc:mysql://localhost:3307/studentdbdemo?createDatabaseIfNotExist=true";
		String uname="root";
		String pwd="root";
		
		DriverManager.getConnection(url,uname, pwd);
		System.out.println("established");
		

	}

}
