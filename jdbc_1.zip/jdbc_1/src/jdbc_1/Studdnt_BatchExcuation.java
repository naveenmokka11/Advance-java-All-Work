package jdbc_1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Studdnt_BatchExcuation {

	public static void main(String[] args) throws Throwable {
		int row = 1;

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter student id");
		int id1 = sc.nextInt();
		System.out.println("Enter Student Name");
		String name1 = sc.next();
		System.out.println("Enter student email");
		String email1 = sc.next();
		System.out.println("Enter student phone");
		Long phone1 = sc.nextLong();
		System.out.println("enter student password");
		String pwd1 = sc.next();

		StudentDao obj1 = new StudentDao();
		obj1.setId(id1);
		obj1.setName(name1);
		obj1.setEmail(email1);
		obj1.setPhone(phone1);
		obj1.setPassword(pwd1);

		System.out.println(row++ + " row data enterd ");

		System.out.println("Enter student id");
		int id2 = sc.nextInt();
		System.out.println("Enter Student Name");
		String name2 = sc.next();
		System.out.println("Enter student email");
		String email2 = sc.next();
		System.out.println("Enter student phone");
		Long phone2 = sc.nextLong();
		System.out.println("enter student password");
		String pwd2 = sc.next();

		StudentDao obj2 = new StudentDao();
		obj2.setId(id2);
		obj2.setName(name2);
		obj2.setEmail(email2);
		obj2.setPhone(phone2);
		obj2.setPassword(pwd2);
		System.out.println(row++ + " row data enterd ");

		System.out.println("Enter student id");
		int id3 = sc.nextInt();
		System.out.println("Enter Student Name");
		String name3 = sc.next();
		System.out.println("Enter student email");
		String email3 = sc.next();
		System.out.println("Enter student phone");
		Long phone3 = sc.nextLong();
		System.out.println("enter student password");
		String pwd3 = sc.next();

		StudentDao obj3 = new StudentDao();
		obj3.setId(id3);
		obj3.setName(name3);
		obj3.setEmail(email3);
		obj3.setPhone(phone3);
		obj3.setPassword(pwd3);

		System.out.println(row++ + " row data enterd ");
		StudentDao obj4 = new StudentDao();

		String url = "jdbc:mysql://localhost:3306/studentdb";
		String pwd = "root";
		String user = "root";
		Connection con = DriverManager.getConnection(url, user, pwd);
		PreparedStatement stat = con.prepareStatement("insert into student values(?,?,?,?,?)");

		List<StudentDao> list = new ArrayList<StudentDao>();

		list.add(obj1);
		list.add(obj2);
		list.add(obj3);

		int a = 1;
		int b = 1;
		for (StudentDao studentDao : list) {
			System.out.println();
			System.out.println(a++ + "data recived");
			stat.setInt(1, studentDao.getId());
			stat.setString(2, studentDao.getName());
			stat.setString(3, studentDao.getEmail());
			stat.setLong(4, studentDao.getPhone());
			stat.setString(5, studentDao.getPassword());
			System.out.println();

			stat.addBatch();
			System.out.println(b++ + "added into batch");
		}
		stat.executeBatch();
		System.out.println("batch excuted");
		System.out.println("program terminated");
	}

}
