package jdbc_1;

import java.sql.Connection;
import java.util.*;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class RetrivingData {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {	
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/studentdb?user=root&password=root");
		Scanner sc=new Scanner(System.in);
		System.out.println("enter student id");
			int id=sc.nextInt();
			PreparedStatement stat = con.prepareStatement("select * from student where id=?");

			stat.setInt(1, id);
			ResultSet res = stat.executeQuery();
			while(res.next()) {
				System.out.println(res.getInt("id"));
				System.out.println(res.getString("name"));
				System.out.println(res.getString("email"));
				System.out.println(res.getLong("phone"));
				System.out.println(res.getString("password"));
				System.out.println("-------------------------");
				
			
			}
			con.close();
			stat.close();
			
			
	}

}






	
