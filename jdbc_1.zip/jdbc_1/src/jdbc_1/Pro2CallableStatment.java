package jdbc_1;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class Pro2CallableStatment {

	public static void main(String[] args) throws IOException, SQLException {
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			String url="jdbc:mysql://localhost:3307/studentdb";
			FileInputStream fip=new FileInputStream("app.properties");
			Properties p=new Properties();
			p.load(fip);
			DriverManager.getConnection(url, p);
	}

}
