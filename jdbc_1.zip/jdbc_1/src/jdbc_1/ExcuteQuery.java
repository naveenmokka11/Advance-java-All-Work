package jdbc_1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ExcuteQuery {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {	
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307/studentdb?user=root&password=root");
				PreparedStatement stat = con.prepareStatement("delete from student  where id=1");
					int res = stat.executeUpdate();
					System.out.println(res);
					con.close();
					stat.close();
					
					
			}	


	}


