package jdbc_1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Statment1 {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("rigester is sucess");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		String url="jdbc:mysql://localhost:3307/studentdb" ;
		String username="root";
		String pwd="root";
		try {
		Connection con = DriverManager.getConnection(url, username, pwd);
			System.out.println("connection is sucess");
			System.out.println(con);
			Statement sta = con.createStatement();
			sta.execute("insert into student values(4,'midhun','midhun@gmail.com',893456777,'midun@123')");
			System.out.println("insertion done");
			sta.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	
				

	}

}
