package jdbc_1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class ExtablishConByUsingSingleArg {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Your are udating the name , mail  based on id");
		System.out.println("enter name");
		String name = sc.next();
		System.out.println("enter mail");
		String mail = sc.next();
		System.out.println("enter id");
		int id=sc.nextInt();

		Class.forName("com.mysql.cj.jdbc.Driver");
		
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307/studentdb?user=root&password=root");
		PreparedStatement stat = con.prepareStatement("update student set name=?,mail=? where id=?");
		
		stat.setString(1, name);
		stat.setString(2, mail);
		stat.setInt(3, id);
		boolean res = stat.execute();
		System.out.println(res);
		
		stat.close();
		con.close();
		sc.close();

		System.out.println("done...");
	}

}
