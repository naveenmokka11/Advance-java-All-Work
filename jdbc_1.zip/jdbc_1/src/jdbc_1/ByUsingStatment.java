package jdbc_1;

import java.sql.DriverManager;
import java.sql.SQLException;

public class ByUsingStatment {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Rigister process is Sucessful");
			} 
		catch (ClassNotFoundException e) {
		System.out.println("External jar is not Avilable(or) Check once Fully Qualified Name Once");
			e.printStackTrace();
			}
		String url="jdbc:mysql://localhost:3307/studentdb" ;
		String username="root";
		String pwd="root";
		try {
			DriverManager.getConnection(url, username, pwd);
			System.out.println("connection is success");
		} catch (SQLException e) {
			System.out.println("please check url, username, passord once");
			e.printStackTrace();
		}

	}

}
