package com.jdbc.mypracticedaily;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.Scanner;

public class CreatesSchema {

	public static void main(String[] args) throws ClassNotFoundException, IOException, SQLException {

		Class.forName("com.mysql.cj.jdbc.Driver");
		System.out.println("loading is done");
		FileInputStream fip = new FileInputStream("app.properties");
		Properties prop = new Properties();
		prop.load(fip);
		String url = "jdbc:mysql://localhost:3306/studentdb?createDatabaseIfNotExist=true";
		Connection con = DriverManager.getConnection(url, prop);
		Statement stat = con.createStatement();
		// stat.execute("drop table if exists emp");
		Scanner sc = new Scanner(System.in);
		System.out.println("enter id");
		int id = sc.nextInt();
		System.out.println("enter name");
		String name = sc.next();
		System.out.println("enter phone");
		long phone = sc.nextLong();
		System.out.println("enter email");
		String email = sc.next();
		System.out.println("enter password");
		String pwd = sc.next();

stat.execute("create table If Not Exists extra_info(id int primary key,name varchar(50),email varchar(50),phone bigint,password varchar(50))");

		CallableStatement res = con.prepareCall("call studentinsert(?,?,?,?,?)");
		res.setInt(1, id);
		res.setString(2, name);
		res.setLong(4, phone);
		res.setString(3, email);
		res.setString(5, pwd);

		  int n = res.executeUpdate();
		System.out.println(n+"row inserted");
		res.close();
		con.close();
		stat.close();
		sc.close();
		
	}

}
