package com.jdbc.mypracticedaily;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.*;

import com.mysql.cj.jdbc.Driver;

public class ByUsingdotProFile {

	public static void main(String[] args) throws SQLException, IOException {
		// loading
		Driver d = new Driver();
		DriverManager.registerDriver(d);
		// establish connection
		String url = "jdbc:mysql://localhost:3307/user_data";
		FileInputStream fis = new FileInputStream("app.properties");
		Properties p = new Properties();
		p.load(fis);
		System.out.println("loading is done");
		Connection con = DriverManager.getConnection(url, p);
		System.out.println("connection established");
		//create statement
		Statement stat = con.createStatement();
		//Execute Statement
		stat.execute("create table demodata(id int primary key,name varchar(20),city varchar(20))");
		System.out.println("table is created");
		Scanner sc = new Scanner(System.in);
		System.out.println("enter id");
		int id = sc.nextInt();
		System.out.println("enter name");
		String name = sc.next();
		System.out.println("enter city");
		String city = sc.next();
		
		PreparedStatement ps = con.prepareStatement("insert into demodata values(?,?,?)");

		ps.setInt(1, id);
		ps.setString(2, name);
		ps.setString(3, city);
		//Execute statement
		ps.execute();
		stat.close();
		con.close();
		sc.close();

		System.out.println("data inserted");

	}

}
