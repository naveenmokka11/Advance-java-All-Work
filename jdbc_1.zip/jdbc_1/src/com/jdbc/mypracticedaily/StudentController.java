package com.jdbc.mypracticedaily;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class StudentController {

	public static void main(String[] args) throws Throwable {
		Scanner sc = new Scanner(System.in);
		int a = 1;
		System.out.println("please enter your name");
		String uname = sc.next();
		System.out.println(uname + " you can insert 3 students data at a time in this applaction");

		System.out.println("enter student id");
		int id1 = sc.nextInt();
		System.out.println("enter name of the student");
		String name1 = sc.next();
		System.out.println("enter email of the student");
		String email1 = sc.next();
		System.out.println("enter phone of the student");
		long phone1 = sc.nextLong();
		System.out.println("enter password");
		String pwd1 = sc.next();

		System.out.println(a++ + " row student data inserted");
		System.out.println();

		StudentDao obj1 = new StudentDao();
		obj1.setId(id1);
		obj1.setName(name1);
		obj1.setEmail(email1);
		obj1.setPhone(phone1);
		obj1.setPassword(pwd1);

		System.out.println(a + " row student data got from" + uname);

		System.out.println("enter student id");
		int id2 = sc.nextInt();
		System.out.println("enter name of the student");
		String name2 = sc.next();
		System.out.println("enter email of the student");
		String email2 = sc.next();
		System.out.println("enter phone of the student");
		long phone2 = sc.nextLong();
		System.out.println("enter password");
		String pwd2 = sc.next();

		StudentDao obj2 = new StudentDao();
		obj2.setId(id2);
		obj2.setName(name2);
		obj2.setEmail(email2);
		obj2.setPhone(phone2);
		obj2.setPassword(pwd2);

		System.out.println(a++ + " row student data got from" + uname);
		System.out.println();

		System.out.println("enter student id");
		int id3 = sc.nextInt();
		System.out.println("enter name of the student");
		String name3 = sc.next();
		System.out.println("enter email of the student");
		String email3 = sc.next();
		System.out.println("enter phone of the student");
		long phone3 = sc.nextLong();
		System.out.println("enter password");
		String pwd3 = sc.next();

		StudentDao obj3 = new StudentDao();
		obj3.setId(id3);
		obj3.setName(name3);
		obj3.setEmail(email3);
		obj3.setPhone(phone3);
		obj3.setPassword(pwd3);
		System.out.println(a + " row student data got from" + uname);
		System.out.println();

		
		String url = "jdbc:mysql://localhost:3306/studentdb";
		String user = "root";
		String pwd = "root";
		Connection con = DriverManager.getConnection(url, user, pwd);
		PreparedStatement stat = con.prepareStatement("insert into student values(?,?,?,?,?)");
		List<StudentDao> li = new ArrayList();
		li.add(obj1);
		li.add(obj2);
		li.add(obj3);

		for (StudentDao studentDao : li) {

			stat.setInt(1, studentDao.getId());
			stat.setString(2, studentDao.getName());
			stat.setString(3, studentDao.getEmail());
			stat.setLong(4, studentDao.getPhone());
			stat.setString(5, studentDao.getPassword());
			stat.addBatch();
		}
		stat.executeBatch();

	}

}
