package com.jdbc.mypracticedaily;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.mysql.cj.jdbc.Driver;

public class Insert {

	public static void main(String[] args) throws SQLException {
		Scanner sc=new Scanner(System.in);
		System.out.println("inserting data into emp table");
		System.out.println("enter id");
		int id=sc.nextInt();
		System.out.println("enter name");
		String name=sc.next();
		System.out.println("enter job");
		String job=sc.next();
		System.out.println("enter email");
		String email=sc.next();
		System.out.println("enter phone number");
		long phone=sc.nextLong();
		//loading is done
		Driver d = new Driver();
		DriverManager.registerDriver(d);
		System.out.println("loading is done.....");
		//establish the connection
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307/emp?user=root&password=root");
		System.out.println("established connection....");
		PreparedStatement stat = con.prepareStatement("insert into emp values(?,?,?,?,?)");
		stat.setInt(1, id);
		stat.setString(2, name);
		stat.setString(3, job);
		stat.setString(4, email);
		stat.setLong(5, phone);
		stat.execute();
		con.close();
		stat.close();
		sc.close();
		
	}

}
