package com.assigenment.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class ByUsingPreparedStatment_P3 {

	public static void main(String[] args) {
		//delete a record based on name
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
	
			e.printStackTrace();
		}
		String url="jdbc:mysql://localhost:3307/studentdb";
		String uname="root";
		String pwd="root";
		Scanner sc=new Scanner(System.in);
		System.out.println("enter student name");
		String name=sc.next();
		try {
			Connection con = DriverManager.getConnection(url, uname, pwd);
			PreparedStatement stat = con.prepareStatement("delete from student where name=?");
			stat.setString(1, name);
			stat.execute();
			stat.close();
			con.close();
			sc.close();
			System.out.println("sucess");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		

	}

}
