package com.assigenment.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class ByUsingStatment_P2 {
//update student record of id=2 change the Name, Email
	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Load and register is completed");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String url="jdbc:mysql://localhost:3307/studentdb";
		//"jdbc:mysql://localhost:3307/studentdb" ;
		String username="root";
		String pwd="root";
		try {
			Connection con = DriverManager.getConnection(url,username,pwd);
			Statement sta = con.createStatement();
			sta.execute("update student set name='giri',mail='giri@gmail.com' where id=2");
			System.out.println("done");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
