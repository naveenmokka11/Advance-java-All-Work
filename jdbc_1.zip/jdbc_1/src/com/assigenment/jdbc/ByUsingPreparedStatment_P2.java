package com.assigenment.jdbc;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.*;

public class ByUsingPreparedStatment_P2 {

	public static void main(String[] args) throws IOException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		}
		String url = "jdbc:mysql://localhost:3307/studentdb";
//		String uname = "root";
//		String pwd = "root";
		Scanner sc = new Scanner(System.in);
		System.out.println("Your are udating the name , mail  based on id");
		System.out.println("enter name");
		String name = sc.next();
		System.out.println("enter mail");
		String mail = sc.next();
		System.out.println("enter id");
		int id=sc.nextInt();
		FileInputStream fis= new FileInputStream("app.properties");
		Properties p=new Properties();
		p.load(fis);

		try {
			Connection con = DriverManager.getConnection(url,p);
			// update student record of id=2 change the Name, Email
			PreparedStatement stat = con.prepareStatement("update student set name=?,mail=? where id=?");
			
			stat.setString(1, name);
			stat.setString(2, mail);
			stat.setInt(3, id);
			stat.execute();
			
			stat.close();
			con.close();
			sc.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
