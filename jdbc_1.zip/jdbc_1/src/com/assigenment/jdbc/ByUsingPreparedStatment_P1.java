package com.assigenment.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class ByUsingPreparedStatment_P1 {

	public static void main(String[] args) {		
		//loding process
		Scanner sc=new Scanner(System.in);
		System.out.println("Your deleting the student data based on name and mail");
		System.out.println("enter  name");
		String name=sc.next();
		System.out.println("enter email");
		String mail=sc.next();
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
	} catch (ClassNotFoundException e) {
		e.printStackTrace();
	}
	String url="jdbc:mysql://localhost:3306/studentdb";
	String uname="root";
	String pwd="root";
	try {
	Connection con = DriverManager.getConnection(url, uname, pwd);
	//delete a record based on name and email
		PreparedStatement stat =
		con.prepareStatement("delete from student where (name= ? and mail=?)");
		stat.setString(1, name);
		stat.setString(2, mail);
		stat.execute();
		stat.close();
		con.close();
		sc.close();
		System.out.println("sucess");

		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	

	}

}
